total_hours_worked = float(input("Please Enter total number of hours worked: "))
hourly_pay_rate = float(input("Please enter your hourly pay rate: "))
gross_pay = total_hours_worked * hourly_pay_rate
print("Your gross pay is: " , gross_pay)
